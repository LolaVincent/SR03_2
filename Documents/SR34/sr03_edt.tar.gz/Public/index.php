<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title> Emploi du temps </title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
		<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="tab.css">
	</head>
	<body>
		<script type="text/javascript">
				function testSaisie(){
					if (document.forms["formulaire"].elements["loginInput1"].value.length == 0){
						return false;
					}
					return true;	
				}
		</script>
		<form class="form-inline" method="post" name="formulaire" onSubmit="return testSaisie()">
			<div class="form-group">
				<label for="loginInput1">Premier login</label>
				<input type="text" class="form-control" id="loginInput1" name="loginInput1" placeholder="Login">
				<label for="loginInput2">Deuxième login</label>
				<input type="text" class="form-control" id="loginInput2" name="loginInput2" placeholder="Login">
			</div>
			<button type="submit" class="btn btn-default">Valider</button>
		</form>	

		<?php if(isset($_POST['loginInput1'])) {
			include 'tab2.php'; 
		} ?>

	</body>
</html>
